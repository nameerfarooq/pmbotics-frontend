import React from 'react'
// eslint-disable-next-line
import CreateProject from '../Project/CreateProject'
// eslint-disable-next-line
import MainProjectScreen from '../Project/MainProjectScreen'
import ViewProject from '../Project/ViewProject'
import TeamMemberWindow from '../TeamMembers/TeamMemberWindow'
import './style.css'
function DashboardMain() {
    return (
        <div className='DashboardMain'>
            
           {/* Main Screen for projects (view and create new)  */}
            {/* <MainProjectScreen /> */}
            
            {/* create project screen */}
            {/* <CreateProject/> */}
            
            {/* view project screen */}
            <ViewProject/>
            
            {/* <TeamMemberWindow /> */}
            
        </div>
    )
}

export default DashboardMain