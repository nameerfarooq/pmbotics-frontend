import React from 'react'
import './projects.css'
import Button from 'react-bootstrap/Button';
import { useState } from 'react';
import MyVerticallyCenteredModal from './MyVerticallyCenteredModal';
function ViewProject() {

    const [show, setShow] = useState(false);

    const handleClose = () => setShow(false);
    const handleShow = () => setShow(true);


    return (

        <div className='ViewProjectMainDiv'>


            <h1 className='PV-PTitle'>PMBOTICS</h1>
            <p>
                Lorem ipsum, dolor sit amet consectetur adipisicing elit. Optio, earum. Voluptatum magni fugiat possimus sit eos voluptatibus illo assumenda, dolore facere, repudiandae neque ut recusandae nam maxime non, ipsam beatae.
                Lorem ipsum, dolor sit amet consectetur adipisicing elit. Optio, earum. Voluptatum magni fugiat possimus sit eos voluptatibus illo assumenda, dolore facere, repudiandae neque ut recusandae nam maxime non, ipsam beatae.
            </p>
            <div className='PV-Cardholder'>

                <div className='PV-Cards'>

                    <h3 className='PV-cards-heading'>
                        Live Project
                    </h3>
                    <div className='PV-cards-section'>
                        Click on the button to view the documents of this project upload by team members of the group
                    </div>
                    <Button variant="primary" onClick={() => handleShow(true)}>
                        View
                    </Button>
                    <MyVerticallyCenteredModal
                        Details={
                            [
                                'Live Project',
                                'Click to view Live Project',
                            'Not available right now !'
                            ]
                        }
                        show={show}
                        onHide={() => handleClose(false)}
                    />
                </div>
                <div className='PV-Cards'>

                    <h3 className='PV-cards-heading'>
                        Documents
                    </h3>
                    <div className='PV-cards-section'>
                        Click on the button to view the documents of this project upload by team members of the group
                    </div>
                    <Button variant="primary" onClick={() => handleShow(true)}>
                        View
                    </Button>
                    <MyVerticallyCenteredModal
                        show={show}
                        onHide={() => handleClose(false)}
                    />
                </div>
                <div className='PV-Cards'>

                    <h3 className='PV-cards-heading'>
                        Supervisor
                    </h3>
                    <div className='PV-cards-section'>
                        Click on the button to view the documents of this project upload by team members of the group
                    </div>
                    <Button variant="primary" onClick={() => handleShow(true)}>
                        View
                    </Button>
                    <MyVerticallyCenteredModal
                        show={show}
                        onHide={() => handleClose(false)}
                    />
                </div>
                <div className='PV-Cards'>

                    <h3 className='PV-cards-heading'>
                        Members
                    </h3>
                    <div className='PV-cards-section'>
                        Click on the button to view the documents of this project upload by team members of the group
                    </div>
                    <Button variant="primary" onClick={() => handleShow(true)}>
                        View
                    </Button>
                    <MyVerticallyCenteredModal
                        show={show}
                        onHide={() => handleClose(false)}
                    />
                </div>


            </div>

            <MyVerticallyCenteredModal />

        </div>




    )
}

export default ViewProject